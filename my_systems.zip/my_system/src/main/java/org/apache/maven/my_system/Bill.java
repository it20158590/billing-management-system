package org.apache.maven.my_system;

public class Bill {
	private int bill_no;
	private int unit;
	private int tax;
	private int total;
	private int fixed_charge;
	private int cid;
	public int getBill_no() {
		return bill_no;
	}
	public void setBill_no(int bill_no) {
		this.bill_no = bill_no;
	}
	public int getUnit() {
		return unit;
	}
	public void setUnit(int unit) {
		this.unit = unit;
	}
	public int getTax() {
		return tax;
	}
	public void setTax(int tax) {
		this.tax = tax;
	}
	public int getTotal() {
		return total;
	}
	public void setTotal(int total) {
		this.total = total;
	}
	public int getFixed_charge() {
		return fixed_charge;
	}
	public void setFixed_charge(int fixed_charge) {
		this.fixed_charge = fixed_charge;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	
	
	

}
